package Controller;

import java.util.Scanner;
import Model.Athlete;
import static MyLibrary.DataValidation.readIntBetweenMinAndMax;
import static MyLibrary.DataValidation.readStringID;
import java.util.ArrayList;
import Controller.RaceController;
import static Controller.RaceController.getRaceByID;
import static Controller.RaceController.idRaceRepeated;
import static Controller.RaceController.viewRaces;
import Model.Race;

/**
 *
 * @author Afnan
 */
public class AthleteController {

    //Aquí creo un objeto que está nulo.
    private static ArrayList<Athlete> athletes = new ArrayList<>();

    public static ArrayList<Athlete> getAthletes() {
        return athletes;
    }

    //Método para ver si el id del Atleta se repite
    /**
     * Lo que hago es devolver un booleano, si repite o no, en el parámetro
     * pongo el string id que cogerá para compararlo
     */
    public static boolean idAthleteRepeated(String id) {
        boolean IDrepeated = false;

        //Recorrido de todo el array y si existe id que devuelve un true.
        for (int i = 0; i < athletes.size() && !IDrepeated; i++) {
            if (athletes.get(i).getID().equals(id)) {
                IDrepeated = true;
            }
        }

        return (IDrepeated);
    }

    public static void registerAthlete() {
        Scanner sc = new Scanner(System.in);
        System.out.println("###################################");

        //Si todos los arrays están no nulos, no podrá crear atletas
        /**
         * Empieza a registrar empezando con el ID
         */
        System.out.println("Getting started with athlete registration.");

        System.out.println("Enter the ID: ");
        String id;
        id = readStringID();

        if (!idAthleteRepeated(id)) {

            System.out.println("Athlete name");
            String name = sc.nextLine();
            boolean exit = false;

            do {
                System.out.println("Do yo want to enter optional parameters[Y][N]");
                char option = sc.next().charAt(0);

                if (option == 'N') {
                    athletes.add(new Athlete(id, name));
                    exit = true;

                } else if (option == 'Y') {

                    System.out.println("Athlete age");
                    int age = sc.nextInt();
                    athletes.add(new Athlete(id, name, age));

                    exit = true;

                } else {
                    System.out.println("Put a right option.");
                }

            } while (!exit);

            //Finalmente se guardaran en la posición libre que esté.
            System.out.println("--Athlete registering complete--");
        } else {
            //Entrará aquí cuando detecte que el id del atleta ya está registrado.
            System.out.println("This athlete has already been registered.");
        }
    }

//Este método muestra todos los atletas recorriéndolo.
    public static void viewAthletes() {

        System.out.println("#######Registered Athletes########");
        if (athletes.isEmpty()) {
            System.out.println("No have athletes to view.");
        } else {
            for (int i = 0; i < athletes.size(); i++) {

                boolean race = false;

                System.out.println("ID: " + athletes.get(i).getID());
                System.out.println("BIB: " + athletes.get(i).getBib());
                System.out.println("Name: " + athletes.get(i).getName());
                System.out.println("Age: " + athletes.get(i).getAge());
                System.out.println("······Races ran by " + athletes.get(i).getName()+"······");
                for (int j = 0; j < athletes.get(i).getAthleteRaces().size(); j++) {
                    System.out.println("Race ID: " + athletes.get(i).getAthleteRaces().get(j).getID());
                    System.out.println("Location: " + athletes.get(i).getAthleteRaces().get(j).getLocalidad());
                    System.out.println("··············································");
                }

                if (athletes.get(i).getAthleteRaces().isEmpty()) {
                    System.out.println("This athlete not registered in races.");
                }

                System.out.println("--------------------------------");
            }
        }

    }

    /*Método que modifica atleta, una vez que sepa que hay datos dentro del objeto.
    Cuando vea que existe el Id, dará la opción de modificar el dato que quiera.
    Antes de eso guarda en athToMod la dirección del athleta que quiera modificar.
     */
    public static void modifyAthlete() {
        Scanner sc = new Scanner(System.in);

        if (athletes == null) {
            System.out.println("No athlete registered yet");
        } else {
            System.out.println("Getting started with athlete modification");
            System.out.println("Enter the last ID number:");
            String id = readStringID();

            if (idAthleteRepeated(id)) {
                boolean exit = false;

                do {

                    Athlete athToMod = getAthleteByID(id);
                    System.out.println("----Modify athlete: " + athToMod.getName());
                    System.out.println("What attribute do you want to modify?");
                    System.out.println("[1] Name");
                    System.out.println("[2] Races");
                    System.out.println("[3] Age");
                    System.out.println("[4] Exit modify menu");

                    switch (sc.nextInt()) {
                        case 1:
                            System.out.println("Enter the new name: ");
                            sc.nextLine();
                            athToMod.setName(sc.nextLine());
                            break;
                        case 2:
                            sc.nextLine();
                            boolean exit2 = false;
                            do {
                                viewRaces();
                                System.out.println("2.1- Enter the last number of race code: ");
                                String codeRace = readStringID();
                                if (idRaceRepeated(codeRace)) {
                                    Race race = getRaceByID(codeRace);
                                    
                                    if (!race.getRaceAthletes().contains(athToMod)) {
                                        athToMod.getAthleteRaces().add(race);
                                        race.getRaceAthletes().add(athToMod);
                                        System.out.println("Athlete is regitsered succesfully in race "+race.getLocalidad());
                                    }else{
                                        System.out.println("This athlete is already included in this race.");
                                    }
                                }else{
                                    System.out.println("This race doesn't exist.");
                                }
                                
                                System.out.println("Do you want to continue inserting races? [Y][N]");
                                String option = sc.nextLine();
                                if (!option.equalsIgnoreCase("Y") && !option.equalsIgnoreCase("N")) {
                                    System.out.println("Wrong option");
                                }else if(option.equalsIgnoreCase("N")){
                                    exit2 = true;
                                }
                            } while (!exit2);
                            
                            break;
                        case 3:
                            System.out.println("Enter the new age");
                            int edad;
                            do {

                                edad = sc.nextInt();
                                athToMod.setAge(edad);

                            } while (edad > 0);

                            break;
                        case 4:
                            exit = true;
                            break;

                        default:
                            System.out.println("Wrong option. Try again.");
                    }
                } while (!exit);

            } else {
                System.out.println("Not exist athlete with ID:" + id);
            }
        }

    }

    /*
    Método que devulve Objeto Atleta, de parámetro pasamos el ID,
    busca en todas las posiciones de atleta si existe el ID, cuando lo encuentra, lo guarda en la variable
    athToMod el objeto entero y lo devuelve.
     */
    public static Athlete getAthleteByID(String id) {

        Athlete athToMod = null;

        for (int i = 0; i < athletes.size(); i++) {
            if (athletes.get(i).getID().equals(id)) {
                athToMod = athletes.get(i);
                break;
            }
        }

        return (athToMod);

    }

    /*Método para eliminar Atleta, primero ve si hay datos en el objeto, si hay
    Pones el ID, si el Id coincide entra en el bloque, después en el método posicion volvemos 
    a buscar ID y cuando la encuentra, la declará en nulo.
     */
    public static void deleteAthlete() {
        if (athletes == null) {
            System.out.println("No have athletes to delete.");
        } else {
            System.out.println("Getting starte with athlete deletion");
            System.out.println("Enter the last ID number: ");
            String id = readStringID();

            if (idAthleteRepeated(id)) {
                Athlete athToRemove = getAthleteByID(id);
                athletes.remove(athToRemove);
                
                for (Race race : RaceController.getRaces()) {
                    if (race.getRaceAthletes().contains(athToRemove)) {
                        System.out.println("Athlete deleted.");
                        race.getRaceAthletes().remove(athToRemove);
                    }
                }
            } else {
                System.out.println("Athlete not found");
            }
        }
    }

}
