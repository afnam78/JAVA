/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import java.util.ArrayList;
import Model.Race;
import java.util.Scanner;
import Controller.AthleteController;
import Model.Athlete;
import static MyLibrary.DataValidation.readStringID;
import static MyLibrary.DataValidation.readIntBetweenMinAndMax;

/**
 *
 * @author Afnan
 */
public class RaceController {
//Inicializamos ArrayList Race;

    private static ArrayList<Race> race = new ArrayList<>();

    //Método quue devuleve objeto tipo Race;
    public static ArrayList<Race> getRaces() {
        return race;
    }

    //Método que devuelve booleano, si existe la carrera, o no.
    public static boolean idRaceRepeated(String id) {
        boolean IDrepeated = false;

        //Recorrido de todo el array y si existe id que devuelve un true.
        for (int i = 0; i < race.size() && !IDrepeated; i++) {
            if (race.get(i).getID().equals(id)) {
                IDrepeated = true;
            }
        }

        return (IDrepeated);
    }

    //Devuelve booleano, pero dentro también muestra los atletas que no están registrados.
    public static boolean showAthleteNotRegisteredInRace(Race Race) {
        boolean freeAthletes = false;

        //Entramos en el for teniendo en cuenta el tamaño del objeto Athlete.
        for (int i = 0; i < AthleteController.getAthletes().size(); i++) {

            //Si los atletas no participan en la carrera que pasamos por el parámetro (Race race) nos devolcerán su nombre y el ID
            //Y significa que hay atletas libres,
            if (!Race.getRaceAthletes().contains(AthleteController.getAthletes().get(i))) {
                System.out.println("Athlete: " + AthleteController.getAthletes().get(i).getName()
                        + "With ID: " + AthleteController.getAthletes().get(i).getID());
                freeAthletes = true;
            }
        }

        return (freeAthletes);

    }

    public static void registerRace() {
        //Guardamos ID, reutilizamos código con readString.
        Scanner sc = new Scanner(System.in);
        System.out.println("<-- Getting started with race registration -->");
        System.out.println("Enter the code: ");
        String id = readStringID();

        //Si no existe ID puede seguir añadiendo datos.
        if (!idRaceRepeated(id)) {
            System.out.println("Enter the location: ");
            String location = sc.nextLine();

            System.out.println("Enter the distance (km): ");
            int distance = readIntBetweenMinAndMax(1, 100);
            String option;

            //Se añade el objeto con sus valores introducidos.
            race.add(new Race(id, location, distance));
            //Guardamos el mismom objeto guardad en registeringRace.
            Race registeringRace = race.get(race.size() - 1);

            do {
                System.out.println("Do you want to register athletes [Y][N]: ");
                option = sc.nextLine();

                if (option.equalsIgnoreCase("Y")) {

                    boolean exit = false;

                    do {//Si quieres guardar atletas:
                        //Te devuelve un true o false, si hay atletas libres o no.
                        if (showAthleteNotRegisteredInRace(registeringRace)) {
                            System.out.println("Enter the last Athlete ID number: ");
                            String idAthlete = readStringID();

                            //Si hay atletas libres, comprueba que existan atletas con el ID introducido.
                            if (AthleteController.idAthleteRepeated(idAthlete)) {

                                if (registeringRace.getRaceAthletes().contains(registeringRace)) {
                                    //Si el atleta ya estaba en esta carrera, ya no puede patticipar.
                                    System.out.println("This athlete already participates in the race.");
                                } else {
                                    //Si no se añade el atleta, y se actualiza los datos tanto del objeto Race, como el Athlete.
                                    registeringRace.getRaceAthletes().add(AthleteController.getAthleteByID(idAthlete));
                                    AthleteController.getAthleteByID(idAthlete).getAthleteRaces().add(registeringRace);
                                    System.out.println("Athlete registered in race.");
                                }
                            }

                        } else {
                            System.out.println("No have athletes to register in race.");
                        }

                        //Da opción de volver a añadir atletas.
                        System.out.println("Do you want to enter another athlete [Y][N]");
                        option = sc.nextLine();

                        if (option.equalsIgnoreCase("N")) {
                            exit = true;
                        } else if (option.equals("Y")) {
                            System.out.println("<-- Start again to enter another athlete -->");
                        } else {
                            System.out.println("Wrong option.");
                        }
                    } while (exit == false);

                } else if (option.equalsIgnoreCase("N")) {
                } else {
                    System.out.println("Wrong option. Enter Y or N.");
                }

            } while (!option.equals("Y") && option.equals("N"));

        }

    }

    public static void viewRaces() {

        //Si está vacío no hay nada que mostrar.
        if (race.isEmpty()) {
            System.out.println("No have races to view.");
        } else {
            //Si no, muestra todas las carreras.
            for (int i = 0; i < race.size(); i++) {
                System.out.println("<---- Race created ---->");
                System.out.println("Race ID: " + race.get(i).getID());
                System.out.println("Location : " + race.get(i).getLocalidad());
                System.out.println("DateTime: " + race.get(i).getDateTime());
                System.out.println("Athletes registered in " + race.get(i).getLocalidad() + ": ");

                //Si ve que no hay atletas registrados
                //o que en la carrera no hay atletas, te dice que no hay nadie registrado.
                if (AthleteController.getAthletes().isEmpty() || race.get(i).getRaceAthletes().isEmpty()) {
                    System.out.println("No have athletes registered in " + race.get(i).getLocalidad() + ".");
                } else {
                    //Si hay algún atleta, te lo muestra.
                    System.out.println("<------------------------->");
                    System.out.println("");
                    for (int j = 0; j < race.get(i).getRaceAthletes().size(); j++) {
                        System.out.println("Name: " + race.get(i).getRaceAthletes().get(j).getName() + " ID: " + race.get(i).getRaceAthletes().get(j).getID());
                        System.out.println("");
                    }
                    System.out.println("<------------------------->");
                }

            }
        }

    }

    public static void deleteRace() {
        //Si no hay carrera, no elimina nada.
        if (race == null) {
            System.out.println("No have races to delete.");
        } else {

            //Sino pide ID y comprueba si hay alguna carrera con ese ID.
            System.out.println("Getting started with race deletion");
            System.out.println("Enter the last ID number: ");
            String id = readStringID();

            if (idRaceRepeated(id)) {

                //Se guarda el objeto en raceToRemove
                Race raceToRemove = getRaceByID(id);

                for (int i = 0; i < raceToRemove.getRaceAthletes().size(); i++) {
                    //Se entra en el for mirando la cantidad de atletas que hay en el objeto.
                    if (Controller.AthleteController.getAthletes().get(i).getAthleteRaces().contains(raceToRemove)) {
                        //si en atletas, hay la dirección de la carrera que queremos eliminar, eliminaremos tanto en atletas, como en race.
                        raceToRemove.getRaceAthletes().remove(i);
                        Controller.AthleteController.getAthletes().get(i).getAthleteRaces().remove(i);
                    }

                }

                race.remove(raceToRemove);

                System.out.println("Race deleted.");
            } else {
                System.out.println("Race not found");
            }
        }
    }

    //Recoge el objeto a través del ID
    public static Race getRaceByID(String id) {

        Race athToMod = null;

        for (int i = 0; i < race.size(); i++) {
            if (race.get(i).getID().equals(id)) {
                athToMod = race.get(i);
                break;
            }
        }

        return (athToMod);

    }
}
