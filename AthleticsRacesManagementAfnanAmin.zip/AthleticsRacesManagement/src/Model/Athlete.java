package Model;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author Afnan
 */
public class Athlete {

    //Aquí creo varios contructores, setters y getters que neceistaré para poner los datos de los atletas.
    private String ID, name;
    private int bib, age;
    //Aquí declar el objeto ArrayList, pero no está creado, es decir está nulo.
    private ArrayList<Race> athleteRaces;
    public static int totalNumberBibs;
    
     public Athlete(String ID, String name, int bib, int age) {
        this.ID = ID;
        this.name = name;
        this.bib = bib;
        athleteRaces = new ArrayList<>();
        this.age = age;
     }

    public Athlete(String ID, String name) {
        this.ID = ID;
        this.name = name;
        this.bib = this.totalNumberBibs++;
        //Aquí creo el arraylist, pero está vacío
        athleteRaces = new ArrayList<>();
        System.out.println("<---- Athlete created ---->Memory Address: " + Athlete.this+" Name: " + name+" BIB: " + bib);
        
    }

    public Athlete(String ID, String name, int age) {
        this.ID = ID;
        this.name = name;
        this.bib = this.totalNumberBibs++;
        //Aquí creo el arraylist, pero está vacío
        athleteRaces = new ArrayList<>();
        this.age = age;

        System.out.println("<---- Athlete created ---->");
        System.out.println("Memory Address: " + Athlete.this);
        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
        System.out.println("BIB: " + bib);
        System.out.println("<------------------------->");
    }

    public ArrayList<Race> getAthleteRaces() {
        return athleteRaces;
    }

    public void setAthleteRaces(ArrayList<Race> athleteRaces) {
        this.athleteRaces = athleteRaces;
    }

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getBib() {
        return bib;
    }

    public void setBib(int bib) {
        this.bib = bib;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

}
