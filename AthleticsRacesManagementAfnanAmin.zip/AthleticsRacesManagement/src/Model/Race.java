/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;


/**
 *
 * @author Afnan
 */
public class Race {

    private String ID, localidad;
    private int distance;
    private LocalDateTime dateTime;
    private ArrayList<Athlete> raceAthletes;

    public LocalDateTime getDateTime() {
        return dateTime;
    }

    public ArrayList<Athlete> getRaceAthletes() {
        return raceAthletes;
    }
    
        public Race(String ID, String localidad, LocalDateTime date, int distance) {
        this.ID = ID;
        this.localidad = localidad;
        this.distance = distance;
        this.dateTime = date;
        raceAthletes = new ArrayList<>();
    }

    public Race(String ID, String localidad, int distance) {
        this.ID = ID;
        this.localidad = localidad;
        this.distance = distance;
        this.dateTime = LocalDateTime.now();
        raceAthletes = new ArrayList<>();
        System.out.println("<---- Race created ----> Memory Address: " + Race.this + " Race ID: " + ID);
    }

    public String getID() {
        return ID;
    }

    public String getLocalidad() {
        return localidad;
    }

    public double getdistance() {
        return distance;
    }
    
    

}
