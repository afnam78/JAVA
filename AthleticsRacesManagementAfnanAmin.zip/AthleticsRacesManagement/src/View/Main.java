/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package View;

import static Controller.AthleteController.deleteAthlete;
import static Controller.AthleteController.modifyAthlete;
import static Controller.AthleteController.registerAthlete;
import static Controller.AthleteController.viewAthletes;
import static Controller.RaceController.deleteRace;
import static Controller.RaceController.registerRace;
import static Controller.RaceController.viewRaces;
import Model.Athlete;
import Model.Race;
import java.util.Scanner;

/**
 *
 * @author Afnan
 */
public class Main {

    public static void autoRegObjects() {
        Controller.AthleteController.getAthletes().add(new Athlete("X5165021", "Afnan"));
        Controller.AthleteController.getAthletes().add(new Athlete("X5165022", "Paco"));
        Controller.AthleteController.getAthletes().add(new Athlete("X5165023", "Juan"));
        Controller.RaceController.getRaces().add(new Race("X5165021", "Barcelona", 90));
        Controller.RaceController.getRaces().add(new Race("X5165022", "Lleida", 49));
        Controller.RaceController.getRaces().add(new Race("X5165023", "Tarragona", 22));
    }


    private static void menu() {
        //Creo un método de menú que lo utilizaré en el main 'Pos eso está en private static'
        System.out.println("###################################");
        System.out.println("##-------------------------------##");
        System.out.println("## WELCOME TO ATHLETE MANAGEMENT ##");
        System.out.println("##-----------AFNAN AMIN----------##");
        System.out.println("##-------------------------------##");
        System.out.println("##·······························##");
        System.out.println("##······[1] REGISTER ATHLETE·····##");
        System.out.println("##······[2] VIEW ATLETHES········##");
        System.out.println("##······[3] MODIFY ATHLETE·······##");
        System.out.println("##······[4] DELETE ATHLETE·······##");
        System.out.println("##······[5] REGISTER RACE········##");
        System.out.println("##······[6] VIEW RACES···········##");
        System.out.println("##······[7] DELETE RACE··········##");
        System.out.println("##······[0] EXIT·················##");
        System.out.println("##·······························##");
        System.out.println("###################################");

    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        boolean exit = false;
        autoRegObjects();
        System.out.println("");
        System.out.println("");
        
        

        do {
            menu();
            switch (sc.nextInt()) {
                case 1 ->
                    registerAthlete();
                case 2 ->
                    viewAthletes();
                case 3 ->
                    modifyAthlete();
                case 4 ->
                    deleteAthlete();
                case 5 ->
                    registerRace();
                case 6 ->
                    viewRaces();
                case 7 ->
                    deleteRace();
                case 0 -> {
                    exit = true;
                    System.out.println("Closing application...");
                }
                default ->
                    System.out.println("Selection not available. Try again.");
            }
            //Llamado al método menu procedemos a elegir la opción que nos interese.

        } while (!exit);

    }
}
