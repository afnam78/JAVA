/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MyLibrary;

import java.util.Scanner;

/**
 *
 * @author Afnan
 */
public class DataValidation {

    //Método para que devuelva un int entre dos números
    public static int readIntBetweenMinAndMax(int min, int max) {

        Scanner sc = new Scanner(System.in);
        int num;
        boolean exit = false;
        System.out.println("Put a number from " + min + " to " + max);
        do {

            num = sc.nextInt();

            if (num <= max && num >= min) {
                exit = true;
            } else {
                System.out.println("Write a correct number.");
                System.out.println("Put a number from " + min + " to " + max);
            }
        } while (!exit);

        return (num);
    }

    //Leo el ID dígito por dígito y me devuelve un String
    public static String readStringID() {
        Scanner sc = new Scanner(System.in);

        //Declaro variables en vacío
        String ID = "X516502";
        int num = 0;
        boolean exit = false;

        do {
            System.out.println("Put a number from 0 to 9:");
            num = sc.nextInt();

            if (num >= 0 && num <=9) {
                ID += String.valueOf(num);
                exit = true;
            } else {
                System.out.println("Wrong number.");
                exit = false;
            }
        } while (!exit);
        
        return(ID);

    }

}
