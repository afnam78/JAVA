/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import static Controller.BeingAdd.getSpecie;
import static Controller.PlanetAdd.getPlanet;
import Model.Andorian;
import Model.Ferengi;
import Model.Human;
import Model.Klingon;
import Model.Nibirian;
import Model.Planets;
import Model.Species;
import Model.Vulcanian;

/**
 *
 * @author Afnan
 */
public class ShowSpeciesGroupBySpecies {

    //Muestra especie agrupando por tipos de especies.
    public static void ShowSpeciesGroupBySpecies() {
        if (getSpecie().isEmpty() || getSpecie() == null) {
            System.out.println("No have Species to show");
        } else {
            System.out.println("--------- Species group by species type ---------");
            System.out.println("-- Humans --");
            for (int i = 0; i < getSpecie().size(); i++) {
                if (getSpecie().get(i) instanceof Human) {
                    System.out.println(getSpecie().get(i));
                }
            }

            System.out.println("-------------------------------------------------");
            System.out.println("-- Vulcanians --");
            for (int i = 0; i < getSpecie().size(); i++) {
                if (getSpecie().get(i) instanceof Vulcanian) {
                    System.out.println(getSpecie().get(i));
                }
            }
            System.out.println("-------------------------------------------------");
            System.out.println("-- Andorians --");
            for (int i = 0; i < getSpecie().size(); i++) {
                if (getSpecie().get(i) instanceof Andorian) {
                    System.out.println(getSpecie().get(i));
                }
            }
            System.out.println("-------------------------------------------------");
            System.out.println("-- Ferengis --");
            for (int i = 0; i < getSpecie().size(); i++) {
                if (getSpecie().get(i) instanceof Ferengi) {
                    System.out.println(getSpecie().get(i));
                }
            }
            System.out.println("-------------------------------------------------");
            System.out.println("-- Nibirians --");
            for (int i = 0; i < getSpecie().size(); i++) {
                if (getSpecie().get(i) instanceof Nibirian) {
                    System.out.println(getSpecie().get(i));
                }
            }
            System.out.println("-------------------------------------------------");
            System.out.println("-- Klingons --");
            for (int i = 0; i < getSpecie().size(); i++) {
                if (getSpecie().get(i) instanceof Klingon) {
                    System.out.println(getSpecie().get(i));
                }
            }

        }
    }
    
    //Método adicional, para la clase Species, para el método equals.
    //Devuelce String con nombre del planeta donde vive en concreto una especie.
    public static String PlanetWhereLiveSpecie(String name){
        Planets planet = null;
        
        for (int i = 0; i < getPlanet().size(); i++) {
            for (int j = 0; j < getPlanet().get(i).getSpeciesInPlanet().size(); j++) {
                if (getPlanet().get(i).getSpeciesInPlanet().get(j).equals(new Species(name))) {
                    planet = getPlanet().get(i);
                }
            }
        }
        
        return planet.getPlanetName();
    }
}
