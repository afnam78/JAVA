/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import static Controller.PlanetAdd.getPlanet;
import static Controller.PlanetAdd.getPlanetByName;
import Model.Andorian;
import Model.Ferengi;
import Model.Human;
import Model.Klingon;
import Model.Nibirian;
import Model.Planets;
import Model.Species;
import Model.Vulcanian;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Afnan
 */
public class BeingAdd {

    //Utilizo arraylist de specie para acceder a ella fácilmente.
    private static ArrayList<Species> Specie = new ArrayList<>();

    public static ArrayList<Species> getSpecie() {
        return Specie;
    }

    //Devuele el ser con el nombre.
    public static Species getSpecieByName(String name) {
        Species Specie = null;
        for (int i = 0; i < getSpecie().size(); i++) {
            if (getSpecie().get(i).equals(new Species(name))) {
                Specie = getSpecie().get(i);
            }
        }

        return Specie;
    }

    public static void addBeing() {
        Scanner sc = new Scanner(System.in);
        //Si no hya planetas no puede añadir nada.
        if (PlanetAdd.getPlanet().isEmpty()) {
            //Si no hay planetas, no agregar especies.
            System.out.println("Can't add Being, no have Planets where add.");
        } else {

            System.out.println("Put the name of being:");
            String nameSpecie = sc.next();

            //Procedemos a crear una especia si no exite otro con mismo nombre.
            if (!Specie.contains(new Species(nameSpecie))) {

                //Selecciona tipo de especie que quiere añadir.
                String SpecieType = BeingType();

                //incializamos las clases.
                Andorian andorian = null;
                Vulcanian vulcanian = null;
                Human human = null;
                Nibirian nibirian = null;
                Klingon klingon = null;
                Ferengi ferengi = null;
                //En este ArrayList, guardaremos los planetas en los que podrá vivir el tipo de especie que vayamos a crear.
                ArrayList<Planets> PlanetsWhereCanAdd = new ArrayList<>();

                //Cuando elige la clase, accede a su método.
                //En cada método de añadir especies, devuelve el tipo de especie con los datos añadidos.
                //En cada método de showPlanet, devuelve un arraylist de los planetas en los que puede vivir el ser.
                if ((SpecieType.equalsIgnoreCase("Andorian"))) {
                    andorian = addAndorian(nameSpecie);
                    PlanetsWhereCanAdd = showPlanet(SpecieType, "");
                } else if ((SpecieType.equalsIgnoreCase("Vulcanian"))) {
                    vulcanian = addVulcanian(nameSpecie);
                    PlanetsWhereCanAdd = showPlanet(SpecieType, "");
                } else if (SpecieType.equalsIgnoreCase("Human")) {
                    human = addHuman(nameSpecie);
                    PlanetsWhereCanAdd = showPlanet(SpecieType, "");
                } else if (SpecieType.equalsIgnoreCase("Nibirian")) {
                    nibirian = addNibirian(nameSpecie);
                    String eat = nibirian.getFood();
                    PlanetsWhereCanAdd = showPlanet(SpecieType, eat);
                } else if (SpecieType.equalsIgnoreCase("Klingon")) {
                    klingon = addKlingon(nameSpecie);
                    PlanetsWhereCanAdd = showPlanet(SpecieType, "");
                } else if (SpecieType.equalsIgnoreCase("Ferengi")) {
                    ferengi = addFerengi(nameSpecie);
                    PlanetsWhereCanAdd = showPlanet(SpecieType, "");
                }

                System.out.println("----- --------- -----");

                //Si hay planetas donde se pueda alñadir:
                if (!PlanetsWhereCanAdd.isEmpty()) {

                    //Pedimos nombre de planeta.
                    System.out.println("Put the name of Planet where can insert specie:");
                    String PlanetName = sc.next();

                    //Si existe se guardará una variable tipo Planeta.
                    if (PlanetsWhereCanAdd.contains(new Planets(PlanetName))) {
                        //GetPlanetByName devuelve un planeta en concreto, con el nombre que le pasamos por parámetro.
                        Planets AddInPlanet = getPlanetByName(PlanetName);

                        if (AddInPlanet.getSpeciesInPlanet().size() == AddInPlanet.getNumHab()) {
                            System.out.println("Planet is full.");
                        } else {
                            //Si no está lleno, pasamos a añadir la especie
                            if ((SpecieType.equalsIgnoreCase("Andorian"))) {
                                AddInPlanet.getSpeciesInPlanet().add(andorian);
                                Specie.add(andorian);
                                System.out.println("Andorian addes correctly.");
                            } else if ((SpecieType.equalsIgnoreCase("Vulcanian"))) {
                                AddInPlanet.getSpeciesInPlanet().add(vulcanian);
                                Specie.add(vulcanian);
                                System.out.println("Vulcanian added correctly.");
                            } else if (SpecieType.equalsIgnoreCase("Human")) {
                                AddInPlanet.getSpeciesInPlanet().add(human);
                                Specie.add(human);
                                System.out.println("Human added correctly.");
                            } else if (SpecieType.equalsIgnoreCase("Nibirian")) {
                                AddInPlanet.getSpeciesInPlanet().add(nibirian);
                                Specie.add(nibirian);
                                System.out.println("Nibirian added correctly.");
                            } else if (SpecieType.equalsIgnoreCase("Klingon")) {
                                AddInPlanet.getSpeciesInPlanet().add(klingon);
                                Specie.add(klingon);
                                System.out.println("Klingon added correctly.");
                            } else if (SpecieType.equalsIgnoreCase("Ferengi")) {
                                AddInPlanet.getSpeciesInPlanet().add(ferengi);
                                Specie.add(ferengi);
                                System.out.println("Ferengi added correctly.");
                            }

                        }
                    } else {
                        System.out.println("Planet not found.");
                    }

                }else{
                    System.out.println("No have planets where can add Species.");
                }

            } else {
                System.out.println("This Specie name exist.");

            }

        }
    }
    //Método que devuelve String, donde elegimos el tipo de especie que queremos añadir.
    public static String BeingType() {
        Scanner sc = new Scanner(System.in);

        boolean exit = true;
        String Being = "";

        do {
            System.out.println("What kind of Being do you want do add?");
            System.out.println("[1] Human");
            System.out.println("[2] Nibirian");
            System.out.println("[3] Ferengi");
            System.out.println("[4] Andorian");
            System.out.println("[5] Klingon");
            System.out.println("[6] Vulcanian");

            switch (sc.nextInt()) {
                case 1:
                    Being = "Human";
                    break;
                case 2:
                    Being = "Nibirian";
                    break;
                case 3:
                    Being = "Ferengi";
                    break;
                case 4:
                    Being = "Andorian";
                    break;
                case 5:
                    Being = "Klingon";
                    break;
                case 6:
                    Being = "Vulcanian";
                    break;
                default:
                    exit = false;
                    System.out.println("Put a correct option.");
            }

        } while (!exit);
        return Being;
    }

    //Método que devuelve ArrayList de planetas disponibles, si hay planetas donde se pueda añadir alguna especie.
    //Paso el parámetro String eat, porque si quiere añadir un Nibirian, puede estar un planeta o en otro.
    public static ArrayList<Planets> showPlanet(String Specie, String eat) {

        ArrayList <Planets> ShowPlanet = new ArrayList<>();
        
        System.out.println("----- Showing planets -----");
        for (int i = 0; i < PlanetAdd.getPlanet().size(); i++) {

            if (!PlanetAdd.getPlanet().get(i).getSpeciesInPlanet().isEmpty()) {
                //Si hay especies, validamos que donde haya andorianos, si queremos añadir vulcanianos, no nos salga para añadirlo en el planeta.
                for (int j = 0; j < PlanetAdd.getPlanet().get(i).getSpeciesInPlanet().size(); j++) {
                    if (Specie == "Vulcanian" && !(PlanetAdd.getPlanet().get(i).getSpeciesInPlanet().get(j) instanceof Andorian)) {
                        System.out.println(PlanetAdd.getPlanet().get(i));
                        ShowPlanet.add(PlanetAdd.getPlanet().get(i));
                    }
                    if (Specie == "Andorian" && !(PlanetAdd.getPlanet().get(i).getSpeciesInPlanet().get(j) instanceof Vulcanian)) {
                        System.out.println(PlanetAdd.getPlanet().get(i));
                        ShowPlanet.add(PlanetAdd.getPlanet().get(i));
                    }

                }
            } else if (PlanetAdd.getPlanet().get(i).getSpeciesInPlanet().isEmpty()) {

                //Si está vacío el planeta, podemos añadir cualquiera de estos.
                if (Specie == "Vulcanian") {
                    System.out.println(PlanetAdd.getPlanet().get(i));
                    ShowPlanet.add(PlanetAdd.getPlanet().get(i));

                }
                if (Specie == "Andorian") {
                    System.out.println(PlanetAdd.getPlanet().get(i));
                    ShowPlanet.add(PlanetAdd.getPlanet().get(i));
                }

            }

            //Si el klingon, no puede estar donde hace calor.
            if (Specie == "Klingon" && !(PlanetAdd.getPlanet().get(i).getClima().equalsIgnoreCase("Warm"))) {
                System.out.println(PlanetAdd.getPlanet().get(i));
                ShowPlanet.add(PlanetAdd.getPlanet().get(i));
            }

            //Si el nibiran come pescado, puede vivir donde haya mar.
            if (Specie == "Nibirian" && eat == "Fish" && (PlanetAdd.getPlanet().get(i).isAcuaticBeing())) {
                System.out.println(PlanetAdd.getPlanet().get(i));
                ShowPlanet.add(PlanetAdd.getPlanet().get(i));
            }

            //Si el nibiran come pescado, puede vivir donde haya flora roja.
            if (Specie == "Nibirian" && eat == "Red Flora" && (PlanetAdd.getPlanet().get(i).isRedFlora())) {
                System.out.println(PlanetAdd.getPlanet().get(i));
                ShowPlanet.add(PlanetAdd.getPlanet().get(i));
            }

            //Si es un ferengi, y no hace frío, puede vivir en el planeta.
            if (Specie == "Ferengi" && !(PlanetAdd.getPlanet().get(i).getClima().equalsIgnoreCase("Cold"))) {
                System.out.println(PlanetAdd.getPlanet().get(i));
                ShowPlanet.add(PlanetAdd.getPlanet().get(i));
            }

            //El humano no molesta tanto.
            if (Specie == "Human") {
                System.out.println(PlanetAdd.getPlanet().get(i));
                ShowPlanet.add(PlanetAdd.getPlanet().get(i));
            }

        }
        return ShowPlanet;
    }

    
    //Rango de Andoriano
    public static String AndorianRank() {
        Scanner sc = new Scanner(System.in);
        String rank = "";
        System.out.println("What type of Andorian is?");
        boolean exit = true;

        do {
            System.out.println("[1] Coach");
            System.out.println("[2] Defender");
            System.out.println("[3] Fighter");
            System.out.println("[4] Knight");

            switch (sc.nextInt()) {
                case 1:
                    rank = "Coach";
                    break;
                case 2:
                    rank = "Defender";
                    break;
                case 3:
                    rank = "Fighter";
                    break;
                case 4:
                    rank = "Knight";
                    break;
                default:
                    exit = false;
                    System.out.println("Put a correct option.");
            }
        } while (exit == false);

        return rank;
    }

    //Para añadir andoriano.
    public static Andorian addAndorian(String name) {
        Scanner sc = new Scanner(System.in);

        String rank = AndorianRank();
        boolean aenar = false;
        boolean aenarExit = true;
        do {
            System.out.println("Is Aenar?[Y][N]");
            String option = sc.nextLine();

            if (!option.equalsIgnoreCase("Y") && !option.equalsIgnoreCase("N")) {
                aenarExit = false;
                System.out.println("Put a correct option.");
            } else if (option.equals("Y")) {
                aenar = true;
            } else if (option.equals("N")) {
                aenar = false;
            }

        } while (aenarExit == false);

        Andorian addAndorian = new Andorian(rank, aenar, name);
        return addAndorian;
    }

    //Añade vulcaniano.
    public static Vulcanian addVulcanian(String name) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Level of meditation: ");
        int meditation;
        boolean meditationExit = false;

        do {
            meditation = sc.nextInt();

            if (meditation >= 0 && meditation <= 10) {
                meditationExit = true;
            } else {
                System.out.println("Put between 0 and 10: ");
            }

        } while (meditationExit == false);

        Vulcanian addVulcanian = new Vulcanian(meditation, name);
        /*Specie.add(addVulcanian);
            SpecieAddInPlanet.getSpeciesInPlanet().add(addVulcanian);
            System.out.println("Vulcanian added correctly.");*/

        return addVulcanian;
    }

    //Añade humano.
    public static Human addHuman(String name) {
        Scanner sc = new Scanner(System.in);
        int age;
        int genderInt;
        String gender = "";
        boolean ageExit = true;
        boolean genderExit = true;

        do {

            ageExit = true;
            genderExit = true;

            System.out.println("Age: ");
            age = sc.nextInt();

            if (age > 130 || age <= 0) {
                ageExit = false;
                System.out.println("Put a age between 1 and 130");

            }

        } while (ageExit == false);

        do {
            genderExit = true;
            System.out.println("Put a gender");
            System.out.println("[1] Female");
            System.out.println("[2] Male");

            switch (sc.nextInt()) {
                case 1:
                    gender = "Female";
                    break;
                case 2:
                    gender = "Male";
                    break;
                default:
                    System.out.println("Put a correct option.");
                    genderExit = false;

            }

        } while (genderExit == false);

        Human addHuman = new Human(age, gender, name);
        return addHuman;
    }

    //Añade nibiriano.
    public static Nibirian addNibirian(String name) {
        Scanner sc = new Scanner(System.in);
        int option = 0;
        String eat = "";

        do {
            System.out.println("What eat this Nibirian?");
            System.out.println("[1] Red Flora");
            System.out.println("[2] Fish");
            option = sc.nextInt();
            switch (option) {
                case 1:
                    eat = "Red Flora";
                    break;
                case 2:
                    eat = "Fish";
                    break;
                default:
                    System.out.println("Put a correct option.");
            }
        } while (option == 0);

        Nibirian addNibirian = new Nibirian(eat, name);
        return addNibirian;
    }

    //Añade klingon.
    public static Klingon addKlingon(String name) {
        Scanner sc = new Scanner(System.in);
        int power = 0;
        do {
            System.out.println("Put the Klingon Power: ");
            power = sc.nextInt();

            if (power > 350 || power < 50) {
                System.out.println("Put between 50 and 350.");
            }
        } while (power > 350 || power < 50);

        Klingon addKlingon = new Klingon(power, name);
        return addKlingon;

    }

    //Añade ferengi.
    public static Ferengi addFerengi(String name) {
        Scanner sc = new Scanner(System.in);
        double latinum = 0;

        do {
            System.out.println("How many Latinum have this Ferengi?");
            latinum = sc.nextInt();
            if (latinum < 0) {
                System.out.println("Have to put positive number");
            }
        } while (latinum < 0);

        Ferengi addFerengi = new Ferengi(latinum, name);
        return addFerengi;

    }

    
    public static void DeleteBeing() {
        Scanner sc = new Scanner(System.in);

        //Si existe especie con el nombre, eliminará. Si no hay especies, saldrá el aviso.
        if (!Specie.isEmpty()) {
            System.out.println("Put the name of Being: ");
            String name = sc.nextLine();

            if (Specie.contains(new Species(name))) {
                Species SpecieToDelete;
                Planets PlanetWhereSpecie = null;
                SpecieToDelete = getSpecieByName(name);

                for (int i = 0; i < getPlanet().size(); i++) {
                    if (getPlanet().get(i).getSpeciesInPlanet().contains(SpecieToDelete)) {
                        PlanetWhereSpecie = getPlanet().get(i);
                        break;
                    }
                }

                PlanetWhereSpecie.getSpeciesInPlanet().remove(SpecieToDelete);
                SpecieToDelete.getPlanetWhereLive().remove(PlanetWhereSpecie);
                Specie.remove(SpecieToDelete);
                System.out.println("Deleted correctly.");
            }
        } else {
            System.out.println("No have Species to remove.");
        }
    }

}
