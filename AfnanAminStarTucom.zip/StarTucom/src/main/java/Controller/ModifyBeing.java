/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import static Controller.BeingAdd.getSpecie;
import static Controller.BeingAdd.getSpecieByName;
import static Controller.PlanetAdd.getPlanet;
import Model.Andorian;
import Model.Ferengi;
import Model.Human;
import Model.Klingon;
import Model.Nibirian;
import Model.Species;
import Model.Vulcanian;
import java.util.Scanner;

/**
 *
 * @author Afnan
 */
public class ModifyBeing {

    //Damos la opcion a elegir la especie que puede modificar.
    public static String showSpecie() {
        Scanner sc = new Scanner(System.in);

        boolean exit = true;
        String Being = "";

        do {
            System.out.println("What kind of Being do you want do add?");
            System.out.println("[1] Human");
            System.out.println("[2] Ferengi");
            System.out.println("[3] Andorian");
            System.out.println("[4] Klingon");
            System.out.println("[5] Vulcanian");

            switch (sc.nextInt()) {
                case 1:
                    Being = "Human";
                    break;
                case 2:
                    Being = "Ferengi";
                    break;
                case 3:
                    Being = "Andorian";
                    break;
                case 4:
                    Being = "Klingon";
                    break;
                case 5:
                    Being = "Vulcanian";
                    break;
                default:
                    exit = false;
                    System.out.println("Put a correct option.");
            }

        } while (!exit);
        return Being;
    }

    public static void ModifyBeing() {
        Scanner sc = new Scanner(System.in);

        //Pedimos nombre y especie del que queremos modificar,
        if (getSpecie().isEmpty()) {
            System.out.println("No have species to modify.");
        } else {

            System.out.println("Put the type os Specie:");
            String SpecieType = showSpecie();

            System.out.println("Put the name of Specie:");
            String name = sc.next();

            if (getSpecie().contains(new Species(name))) {
                Species SpecieToModify = getSpecieByName(name);
                //Entramos en el switch:
                switch (SpecieType) {
                    case "Vulcanian":
                        modifyVulcanian(SpecieToModify);
                        break;
                    case "Andorian":
                        modifyAndorian(SpecieToModify);
                        break;
                    case "Klingon":
                        modifyKlingon(SpecieToModify);
                        break;
                    case "Human":
                        modifyHuman(SpecieToModify);
                        break;
                    case "Ferengi":
                        modifyFerengi(SpecieToModify);
                        break;
                    default:
                        System.out.println("Type of Specie not founded");
                }
            }

        }

    }

    //En cada especie para modificar sus valores int.
    //Validamos si existe especie con ese nombre.
    //Para ello, recorremos el arraylist de especies
    //Si existe el especie concreto con ese nombre, procedemos a cmabiar datos.
    public static void modifyAndorian(Species specie) {
        Scanner sc = new Scanner(System.in);
        Andorian andorianToModify;

        if (!(specie instanceof Andorian)) {
            System.out.println("No have Andorian with this name.");
        } else {
            String rank = BeingAdd.AndorianRank();
            andorianToModify = (Andorian) specie;
            andorianToModify.setRank(rank);
            System.out.println("Andorian updated correctly.");
        }

    }

    public static void modifyVulcanian(Species specie) {
        Scanner sc = new Scanner(System.in);
        Vulcanian vulcanianToModify;

        if (!(specie instanceof Vulcanian)) {
            System.out.println("No have vulcanian with this name.");
        } else {
            int num = -1;

            do {
                System.out.println("Change level of meditation:");
                num = sc.nextInt();
                if (num < 0 || num > 10) {
                    System.out.println("Put number between 0 and 10");
                }
            } while (num < 0 || num > 10);
            vulcanianToModify = (Vulcanian) specie;
            vulcanianToModify.setMeditation(num);
            System.out.println("Vulcanian updated correctly.");
        }
    }

    public static void modifyHuman(Species specie) {
        Scanner sc = new Scanner(System.in);
        Human humanToModify;

        if (!(specie instanceof Human)) {
            System.out.println("No have human with this name.");
        } else {
            int num = -1;

            do {
                System.out.println("Put the age of Human");
                num = sc.nextInt();

                if (num <= 0 || num > 150) {
                    System.out.println("Put a age between 1 and 150");
                }
            } while (num <= 0 || num > 150);
            humanToModify = (Human) specie;
            humanToModify.setAge(num);
            System.out.println("Human updated correctly.");
        }
    }

    public static void modifyKlingon(Species specie) {
        Scanner sc = new Scanner(System.in);
        Klingon klingonToModify;

        if (!(specie instanceof Klingon)) {
            System.out.println("No have klingon with this name.");
        } else {
            int num = -1;

            do {
                System.out.println("Change the power");
                num = sc.nextInt();
                if (num < 50 || num > 150) {
                    System.out.println("Put between 50 and 150");
                }
            } while (num < 50 || num > 150);
            
            klingonToModify = (Klingon) specie;
            klingonToModify.setPower(num);
            System.out.println("Klingon updated correctly.");
        }
    }

    public static void modifyFerengi(Species specie) {
        Scanner sc = new Scanner(System.in);
        Ferengi ferengiToModify;

        if (!(specie instanceof Ferengi)) {
            System.out.println("No have ferengi with this name.");
        } else {
            double num = -1;

            do {
                System.out.println("How many Latinum have?");
                num = sc.nextDouble();
                if (num < 0) {
                    System.out.println("Put a positive number.");
                }
            } while (num < 0);
            ferengiToModify = (Ferengi) specie;
            ferengiToModify.setLatinum(num);
            System.out.println("Ferengi updated correctly.");
        }
    }

}
