/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import Model.Planets;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Afnan
 */
public class PlanetAdd {

    /*Creamos arraylist Planeta para guardar planetas creadas dentro.*/
    private static ArrayList<Planets> Planet = new ArrayList<>();

    //Método que devuelve el arraylist de planetas.
    public static ArrayList<Planets> getPlanet() {
        return Planet;
    }

    public static Planets getPlanetByName(String name) {
        Planets AddInPlanet = null;
        for (int i = 0; i < getPlanet().size(); i++) {
            if (getPlanet().get(i).equals(new Planets(name))) {
                AddInPlanet = getPlanet().get(i);
            }
        }

        return AddInPlanet;
    }

    public static void AddPlanet() {
        Scanner sc = new Scanner(System.in);
        //Pido el nombre, que lo devuelve este método.
        System.out.println("Put the name of Planet:");
        String name = sc.next();
        if (!Planet.contains(new Planets(name))) {
            int num = -1;
            do {
                //Limitar la cantidad de habitantes por planeta.
                System.out.println("How many Species can habitate?");
                num = sc.nextInt();

                if (num <= 0) {
                    System.out.println("Have to put more than 0.");
                }
            } while (num <= 0);

            //Introducimos los datos de planetas necesarios.
            System.out.println("Galaxy: ");
            String galaxy = sc.next();

            System.out.println("Clima: ");
            String clima = Clima();

            boolean flora = Flora();
            boolean acuaticBeing = Acuatic();

            //Añadimos planeta.
            Planet.add(new Planets(name, galaxy, clima, flora, acuaticBeing, num));
            System.out.println("Planet added correctly.");
        } else {
            System.out.println("This name of Planet exist.");
        }

    }

    public static String Clima() {
        //Devuele un String de clima.
        Scanner sc = new Scanner(System.in);
        boolean exit = true;
        String clima = "";

        do {
            System.out.println("[1] Cold");
            System.out.println("[2] Warm");
            System.out.println("[3] Template");

            switch (sc.nextInt()) {
                case 1:
                    clima = "Cold";
                    break;
                case 2:
                    clima = "Warm";

                    break;
                case 3:
                    clima = "Template";

                    break;
                default:
                    System.out.println("Put a correct option");
                    exit = false;

            }
        } while (!exit);

        return clima;

    }

    public static boolean Flora() {
        //Devuelve si tiene flora roja o no.
        Scanner sc = new Scanner(System.in);
        boolean flora = false;
        boolean exitFlora = false;
        do {
            System.out.println("Have red flora?[Y][N]");
            String option = sc.nextLine();
            if (option.equalsIgnoreCase("y")) {
                flora = true;
                exitFlora = true;
            } else if (option.equalsIgnoreCase("n")) {
                flora = false;
                exitFlora = true;
            } else {
                System.out.println("Put a correct option.");
            }
        } while (exitFlora == false);

        return (flora);
    }

    public static boolean Acuatic() {
        //Devuelve sio es acuático o no.
        Scanner sc = new Scanner(System.in);
        boolean acuaticBeing = false;
        boolean exitAcuatic = false;
        do {
            System.out.println("Have acuatic being?[Y][N]");
            String option = sc.nextLine();
            if (option.equalsIgnoreCase("y")) {
                acuaticBeing = true;
                exitAcuatic = true;
            } else if (option.equalsIgnoreCase("n")) {
                acuaticBeing = false;
                exitAcuatic = true;
            } else {
                System.out.println("Put a correct option.");
            }
        } while (exitAcuatic == false);

        return (acuaticBeing);
    }

    public static void ShowSpeciesGroupByPlanets() {
        //Muestra planetas, si está vacío no muestra nada.
        if (getPlanet().isEmpty() || getPlanet() == null) {
            System.out.println("No have planets to Show");
        } else {
            for (int i = 0; i < getPlanet().size(); i++) {
                System.out.println("----------------------------------------------");
                System.out.println(getPlanet().get(i));
                System.out.println("Species in Planet");
                if (!getPlanet().get(i).getSpeciesInPlanet().isEmpty()) {
                    for (int j = 0; j < getPlanet().get(i).getSpeciesInPlanet().size(); j++) {
                        System.out.println(getPlanet().get(i).getSpeciesInPlanet().get(j));
                    }
                } else {
                    System.out.println("No have Species in planet");
                }
                System.out.println("----------------------------------------------");

            }

        }
    }

}
