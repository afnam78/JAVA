/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author Afnan
 */
public class Vulcanian extends Species {

    private int meditation;
    private static String civilization = "III";

    public Vulcanian(int meditation, String nombre) {
        super(nombre, civilization);
        this.meditation = meditation;
    }

    public int getMeditation() {
        return meditation;
    }

    public void setMeditation(int meditation) {
        this.meditation = meditation;
    }
    
    
    

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(super.toString());
        sb.append("Vulcanian{meditation=").append(meditation);
        sb.append('}');
        return sb.toString();
    }

}
