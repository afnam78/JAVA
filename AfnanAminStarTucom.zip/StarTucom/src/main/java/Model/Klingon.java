/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author Afnan
 */
public class Klingon extends Species {

    private int power;
    private static String civilization = "III";

    public Klingon(int power, String nombre) {
        super(nombre, civilization);
        this.power = power;
    }

    public int getPower() {
        return power;
    }

    public void setPower(int power) {
        this.power = power;
    }
    
    

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(super.toString());
        sb.append("Klingon{power=").append(power);
        sb.append('}');
        return sb.toString();
    }

}
