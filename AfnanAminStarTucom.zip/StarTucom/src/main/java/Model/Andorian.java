/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author Afnan
 */
public class Andorian extends Species {

    private String rank;
    private boolean Aenar;
    private static String civilization = "II";

    public Andorian(String rank, boolean Aenar, String nombre) {
        super(nombre, civilization);
        this.rank = rank;
        this.Aenar = Aenar;
    }

    public String getRank() {
        return rank;
    }

    public void setRank(String rank) {
        this.rank = rank;
    }
    
    

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(super.toString());
        sb.append("Andorian{rank=").append(rank);
        sb.append(", Aenar=").append(Aenar);
        sb.append('}');
        return sb.toString();
    }

}
