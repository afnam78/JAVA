/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import java.util.ArrayList;
import java.util.Objects;

/**
 *
 * @author Afnan
 */
public class Planets {

    private static int idPlanet;
    private String planetName;
    private String galaxy;
    private String clima;
    private boolean redFlora;
    private boolean acuaticBeing;
    private ArrayList<Species> SpeciesInPlanet;
    private int numHab;

    public Planets(String planetName) {
        this.planetName = planetName;
    }

    public int getNumHab() {
        return numHab;
    }

    public Planets(String planetName, String galaxy, String clima, boolean redFlora, boolean acuaticBeing, int numHab) {

        this.idPlanet++;
        this.planetName = planetName;
        this.galaxy = galaxy;
        this.clima = clima;
        this.redFlora = redFlora;
        this.acuaticBeing = acuaticBeing;
        this.numHab = numHab;
        this.SpeciesInPlanet = new ArrayList<>();
    }

    public static int getIdPlanet() {
        return idPlanet;
    }

    public String getPlanetName() {
        return planetName;
    }

    public void setPlanetName(String planetName) {
        this.planetName = planetName;
    }

    public String getGalaxy() {
        return galaxy;
    }

    public void setGalaxy(String galaxy) {
        this.galaxy = galaxy;
    }

    public String getClima() {
        return clima;
    }

    public void setClima(String clima) {
        this.clima = clima;
    }

    public boolean isRedFlora() {
        return redFlora;
    }

    public void setRedFlora(boolean redFlora) {
        this.redFlora = redFlora;
    }

    public boolean isAcuaticBeing() {
        return acuaticBeing;
    }

    public void setAcuaticBeing(boolean acuaticBeing) {
        this.acuaticBeing = acuaticBeing;
    }

    public ArrayList<Species> getSpeciesInPlanet() {
        return SpeciesInPlanet;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Planets other = (Planets) obj;
        if (!Objects.equals(this.planetName, other.planetName)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Planets{planetName=").append(planetName);
        sb.append(", galaxy=").append(galaxy);
        sb.append(", clima=").append(clima);
        sb.append(", redFlora=").append(redFlora);
        sb.append(", acuaticBeing=").append(acuaticBeing);
        sb.append('}');
        return sb.toString();
    }

}
