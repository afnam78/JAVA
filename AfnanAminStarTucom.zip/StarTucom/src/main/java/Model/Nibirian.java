/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author Afnan
 */
public class Nibirian extends Species {

    private String food;
    private static String civilization = "III";

    public Nibirian(String food, String nombre) {
        super(nombre, civilization);
        this.food = food;
    }

    @Override
    
    
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(super.toString());
        sb.append("Nibirian{food=").append(food);
        sb.append('}');
        return sb.toString();
    }

    public String getFood() {
        return food;
    }
    
    

}
