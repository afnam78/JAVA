/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author Afnan
 */
public class Ferengi extends Species {

    private double Latinum;
    private static String civilization;

    public Ferengi(double Latinum, String nombre) {
        super(nombre, civilization);
        this.Latinum = Latinum;
    }

    public double getLatinum() {
        return Latinum;
    }

    public void setLatinum(double Latinum) {
        this.Latinum = Latinum;
    }

    
    
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(super.toString());
        sb.append("Ferengi{Latinum=").append(Latinum);
        sb.append('}');
        return sb.toString();
    }

}
