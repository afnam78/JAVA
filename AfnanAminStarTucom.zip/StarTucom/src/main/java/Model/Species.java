/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import static Controller.ShowSpeciesGroupBySpecies.PlanetWhereLiveSpecie;
import java.util.ArrayList;
import java.util.Objects;

/**
 *
 * @author Afnan
 */
public class Species {

    protected String nombre;
    protected String Categoria;
    private ArrayList<Planets> PlanetWhereLive;

    public Species(String nombre, String Categoria) {
        this.nombre = nombre;
        this.Categoria = Categoria;
        this.PlanetWhereLive = new ArrayList<>();

    }

    public Species(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }

    public String getCategoria() {
        return Categoria;
    }

    public ArrayList<Planets> getPlanetWhereLive() {
        return PlanetWhereLive;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        // instanceof = sale true si comprueba datos correctos con sus hijos, con getclas no.
        if (!(obj instanceof Species)) {
            return false;
        }
        final Species other = (Species) obj;
        if (!Objects.equals(this.nombre, other.nombre)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Species{nombre=").append(nombre);
        sb.append(", Categoria=").append(Categoria);
        sb.append(", Planet where live=").append(PlanetWhereLiveSpecie(nombre));
        sb.append('}');
        return sb.toString();
    }

    

}
