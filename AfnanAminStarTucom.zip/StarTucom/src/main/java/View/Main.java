/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package View;

import Controller.BeingAdd;
import Controller.ModifyBeing;
import Controller.ShowSpeciesGroupBySpecies;
import Controller.PlanetAdd;
import java.util.Scanner;


/**
 *
 * @author Afnan
 */
public class Main {

    public static void menu() {
        System.out.println("[1] REGISTER PLANET");
        System.out.println("[2] CENSOR A BEING");
        System.out.println("[3] DELETE A BEING");
        System.out.println("[4] SHOW BEING GROUP BY PLANET");
        System.out.println("[5] MODIFY PROPERTIES OF BEING");
        System.out.println("[6] SHOW BEING GROUP BY SPECIES");
        System.out.println("[0] EXIT");

    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        boolean exit = false;

        do {
            menu();

            switch (sc.nextInt()) {
                case 1 -> PlanetAdd.AddPlanet();
                case 2 -> BeingAdd.addBeing();
                case 3 -> BeingAdd.DeleteBeing();
                case 4 -> PlanetAdd.ShowSpeciesGroupByPlanets();
                case 5 -> ModifyBeing.ModifyBeing();
                case 6 -> ShowSpeciesGroupBySpecies.ShowSpeciesGroupBySpecies();
                case 0 -> {
                    exit = true;
                    System.out.println("BYE!!");
                }
                default -> System.out.println("Put correct option.");
            }
            
        } while (!exit);

    }
}

